<?php

$hostName = "localhost";
 $userName = "couponcode";
 $password = "nhRXfNy2TwbWEpWr";
 $dbName = "couponcode";
 $conn= new mysqli($hostName,$userName,$password,$dbName);
 if($conn){echo "connected";}else{ echo "not connected";}
 
 
date_default_timezone_set('Asia/Kolkata');


/* Posted form data */

if(isset($_POST['submit']))
{
    
  $mobile =  htmlspecialchars($_POST['mobile']);
  $utm_campaign = htmlspecialchars($_POST['utm_campaign']);
  $utm_source = htmlspecialchars($_POST['utm_source']);
  $utm_medium = htmlspecialchars($_POST['utm_medium']);
  //$coupon =strtoupper(date("dMHi").substr ($mobile, -4));
  function generateRandomString($length = 6) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ012345678901234567890123456789';
    $result = '';
    for ($i = 0; $i < $length; $i++) {
        $result .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $result;
    }
  $coupon = generateRandomString();
  $Date = date('Y-m-d');
  $added14days = date('Y-m-d', strtotime($Date. ' + 14 days'));
  $krr    = explode('-', $added14days);
  $added14days = implode("", $krr);
  
  /* php code to coupon code */
  $coupon ="";
  $sql ="SELECT * FROM `couponcode_tbl` WHERE phoneno=".$mobile;
  
  $result = $conn->query($sql);

    if ($result->num_rows > 0) {
       
      while($row = $result->fetch_assoc()) {
       $coupon =  $row["couponcode"];
      }
    } else {
         
      $sql1 = "SELECT * FROM `couponcode_tbl` WHERE phoneno='' LIMIT 1";
      $result1 = $conn->query($sql1);
          if ($result1->num_rows > 0) {
              
          while($row1 = $result1->fetch_assoc()) {
           $coupon =  $row1["couponcode"];
           
           $id = $row1['ID'];
           $sql2 = "UPDATE couponcode_tbl SET phoneno=".$mobile." WHERE id=".$id;
           
               if ($conn->query($sql2) === TRUE) 
               {
                      
                } else 
                {
                      
                }
       
            }
            } else {
              
             //echo "coupon full"; 
              
            }
      
    }
  /* php code to coupon code */
  
  $mapArray = array( "Hyderabad" => "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15224.122504037625!2d78.4453373!3d17.4582482!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90ee67996bbd%3A0x47b94ac2af3aae90!2sAgromech%20Industries!5e0!3m2!1sen!2sin!4v1688713000918!5m2!1sen!2sin", "Coimbatore" =>"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d62661.156919901!2d76.8814514!3d11.0144267!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba858fd4590ee25%3A0xea6851ba58cb548b!2sIdeal%20Stores!5e0!3m2!1sen!2sin!4v1688713415189!5m2!1sen!2sin", "Bengaulru" => "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.9016470135994!2d77.6394985!3d12.9781421!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae16a5020f8351%3A0x7663d050bd3e408d!2sPots%20%26%20Pans!5e0!3m2!1sen!2sin!4v1688713566914!5m2!1sen!2sin", "Kannur" => "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3904.521851774491!2d75.366025!3d11.8687057!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba422cab556fb3b%3A0x90a26fc49a44befb!2sNikshan%20Electronics!5e0!3m2!1sen!2sin!4v1688713648515!5m2!1sen!2sin" );
   
   $dealerArray = array("Hyderabad" => "Agro Mech Industries", "Coimbatore" => "Ideal Stores",  "Bengaulru" => "Pots And Pans Internationa", "Kannur" =>"Nikshan Electronics");
   
   $addressArray = array("Hyderabad" => "B-7, Agromech Industries, Industrial Estate, near Little Scholar School, Sanath Nagar, Hyderabad, Telangana 500018", "Coimbatore" => "8, Bashyakarlu Rd, R.S. Puram, Coimbatore, Tamil Nadu 641002",  "Bengaulru" => "10, Chinmaya Mission Hospital Rd, Stage 1, Indiranagar, Bengaluru, Karnataka 560038", "Kannur" =>"Nikshan Arena, Bank Rd, Kannur, Kerala 670001");
   
   $contactArray = array("Hyderabad" => "9866325626", "Coimbatore" => "9843014521",  "Bengaulru" => "9620365158", "Kannur" =>"9633958269");
   
   /* whats app integration */
    
    $msg =urlencode("Confirmed! ".$coupon.". Here’s your exclusive coupon from Hawkins Cookers Limited that entitles you to 10% off on purchase of one product 15% off on purchase of two products 20% off on purchase of three products. This coupon/offer can be redeemed at ".$addressArray[$utm_campaign]." T&C Apply.");

    $whatsAppUrl = "https://media.smsgupshup.com/GatewayAPI/rest?userid=2000206964&password=QpGRhmGJ&send_to=".$mobile."&v=1.1&format=json&msg_type=TEXT&method=SENDMESSAGE&msg=".$msg;
    //echo $whatsAppUrl;
            $ch = curl_init($whatsAppUrl); 
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET"); 
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Length: 0'));
            $result = curl_exec($ch);
           // print_r($result);exit;
    
   /* whats app integration */
   

   /*  */
  
        /* Generate coupon code */
        
        /* Hawkins database API */
        
            $url = "https://register.hawkins.in/gencouponcodegdnjul2023.aspx?ccd=".$coupon."&custmobno=".$mobile."&vali=".$added14days;
            $ch = curl_init($url); 
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET"); 
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Length: 0'));
            $result = curl_exec($ch);
            //print_r($url);
         
          
        }

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thank you</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">    
</head>

<body>
    <div class="wrapper">
        <div class="header-container mb-3">
            <div class="d-flex align-items-center">
                <div class="haw-logo">
                    <img class="haw-logo-img" src="images/hawkins-logo.png" alt="hawkins-logo" loading="lazy">
                </div>
                <div class="text-heading text-center">
                   <h1>Monsoon<br>Offer!</h1>
                </div> 
            </div>        
        </div>
        <div class="container">
           
            <h2 class="mb-3">Thank you for showing interest!</h2>
            <p>
                You are entitled to the following offer
                On buying 3 Hawkins products in one transaction, you are entitled to a discount of 20% on the MRP of the
                products.
            </p>
            <div class="coupon mb-4">
                <div class="copy-button">
                  <input id="copyvalue" type="text" readonly="" value="<?php echo $coupon;?>">
                  <button onclick="copyIt()" class="copybtn">COPY</button>
                </div>    
            </div>
            <p> To redeem your coupon please visit the dealer mentioned below:</p>
            <div class="dealer-add">
                <?php if(@$dealerArray[$utm_campaign] != ''  ) { ?>
                <h2><?php echo $dealerArray[$utm_campaign];  ?></h2>
                <?php }
                else {
                     ?>
                     <div class="dealer-add">
                                <h2>Ideal Stores</h2>
                                                <p class="mb-0">8, Bashyakarlu Rd, R.S. Puram, Coimbatore, Tamil Nadu 641002 </p>
                                                <span class="icon-call d-inline-block"></span>
                <strong class="mb-3 d-inline-block"><a href="tel:9567546541">9843014521</a></strong>
                         


                                <h2>Agro Mech Industries</h2>
                                                <p class="mb-0">B-7, Agromech Industries, Industrial Estate, near Little Scholar School, Sanath Nagar, Hyderabad, Telangana 500018 </p>
                                                <span class="icon-call d-inline-block"></span>
                <strong class="mb-3 d-inline-block"><a href="tel:9567546541">9866325626</a></strong>
                            

                                <h2>Pots And Pans Internationa</h2>
                                                <p class="mb-0">10, Chinmaya Mission Hospital Rd, Stage 1, Indiranagar, Bengaluru, Karnataka 560038 </p>
                                                <span class="icon-call d-inline-block"></span>
                <strong class="mb-3 d-inline-block"><a href="tel:9567546541">9620365158</a></strong>
                           

                                <h2>Nikshan Electronics</h2>
                                                <p class="mb-0">Nikshan Arena, Bank Rd, Kannur, Kerala 670001 </p>
                                                <span class="icon-call d-inline-block"></span>
                <strong class="mb-3 d-inline-block"><a href="tel:9567546541">9633958269</a></strong>
                            </div>
               <?php }
                ?>
                <?php if(@$addressArray[$utm_campaign] != ''  ) { ?>
                <p class="mb-0"><?php echo $addressArray[$utm_campaign];  ?> </p>
                <?php } ?>
                <?php if(@$contactArray[$utm_campaign] != '' ) { ?>
                <span class="icon-call d-inline-block"></span>
                <strong><a href="tel:9567546541"><?php echo $contactArray[$utm_campaign];  ?></a></strong>
                <?php } ?>
            </div>
            <?php if(@$mapArray[$utm_campaign] != '') { ?> 
            <div id="map">
                <iframe src="<?php echo $mapArray[$utm_campaign] ?>" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <?php }  ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
        crossorigin="anonymous"></script>
    <script>
        let copybtn = document.querySelector(".copybtn");
        
        function copyIt(){
          let copyInput = document.querySelector('#copyvalue');
        
          copyInput.select();
        
          document.execCommand("copy");
        
          copybtn.textContent = "COPIED";
        }
    </script>    
</body>

</html>